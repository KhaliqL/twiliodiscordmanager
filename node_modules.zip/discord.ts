import type {Client as ClientT} from "discord.js";
const Discord = require("discord.js");
const Client = Discord.Client;
const Intents = Discord.Intents;

async function dClient(): Promise<ClientT> {
    const clientD = new Client({
        intents: [
            Intents.FLAGS.GUILDS,
            Intents.FLAGS.GUILD_MESSAGES,
            Intents.FLAGS.DIRECT_MESSAGES
        ],
    });
    await clientD.login(process.env["DISCORD_BOT_TOKEN"]);
    return clientD;
}