import {Twilio} from "twilio";

require("dotenv").config();

let tClient: Twilio = require("./twilio")();
let dClient = require("./discord")();

dClient.on("messageCreate", async (m) => {
    if (m.author.id === process.env["KHALIQS_ID"] && m.content.toLowerCase().startsWith("!broadcast ")) {
        let c = m.content.replace(/^!broadcast\s+/i);
        let notif = tClient.notify.services(process.env["BROADCAST_NOTIFY_SERVICE_SID"]);
        try {
            await notif.notifications.create({
                tag: "all",
                body: c,
            });
            m.reply("Success?!");
        } catch (e) {
            console.log(e);
            m.reply("There was an error.");
        }
    }
});